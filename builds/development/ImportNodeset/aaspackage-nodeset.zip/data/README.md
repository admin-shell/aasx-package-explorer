﻿# Binary files

This file is intended to create an (empty) /data folder in the path of the binary executable.
Within this folder, various necessary files for the successfull operation of AasxGenerate.exe are required.
They could be copied manually or by engaging the CopyExternalData.bat batch.